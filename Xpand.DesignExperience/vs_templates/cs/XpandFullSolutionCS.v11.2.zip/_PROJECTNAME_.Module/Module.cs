using System;
using System.Collections.Generic;

using DevExpress.ExpressApp;
using System.Reflection;


namespace $safesolutionname$.Module {
	public sealed partial class $projectsuffix$Module : ModuleBase {
		public $projectsuffix$Module() {
			InitializeComponent();
		}
    }
}
